package com.company;

public class Draw1 {

    public Draw1() {

    }

    public static void drawLine(int howLong) {
        for (int i = 0; i < howLong; i++) {
            System.out.print("*");
        }
        System.out.println();
    }

    public static void drawKick(int howLong) {
        for (int i = 0; i < howLong; i++) {
            System.out.print(" ");
        }


    }
}