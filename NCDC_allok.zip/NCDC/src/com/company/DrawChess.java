package com.company;

public class DrawChess {

    public DrawChess() {

    }

    public static void drawTile(char actualSign, int tileHeight, int tileWidth, int tilesInRow) {
        int keepTileWidth = tileWidth;
//       int keepTileHight = tileHeight;

        for (int i = 0; i < tilesInRow; i++) {
            tileWidth = keepTileWidth;
            while (tileWidth > 0) {
                System.out.print(actualSign);
                tileWidth--;
            }
            actualSign = DrawChess.chooseSign(actualSign);
        }
        if (tileHeight > 0) {
            tileHeight--;
        } else {
            System.out.println();
            return;
        }
        actualSign = DrawChess.chooseSign(actualSign);
        System.out.println();
        drawTile(actualSign, tileHeight, keepTileWidth, tilesInRow);
    }

    public static char chooseSign(char actualSign) {
        char sign = 'x';
        if (actualSign == 'x') {
            sign = '*';
        } else {
            sign = 'x';
        }
        return sign;
    }
}
