//program draws chess boar with parameters: tileWidth tileHeight tilesInRow tilesInColumn whiteTileSign blackTileSign
package com.company;//na com.ncdc

public class Szachownica1 {

    private static final byte MIN_QUANTITY = 1;
    private static final byte MAX_QUANTITY = 15;
    //    static int tileWidth = 3;
//    static int tileHeight = 3;
//    static int tilesInRow = 4;
//    static int tilesInColumn = 4;
    static char whiteTileSign = 'x';
    static char blackTileSign = '*';

    public static void main(String[] args) {

        byte tileWidth = MIN_QUANTITY;
        byte tileHeight = MIN_QUANTITY;
        byte tilesInRow = MIN_QUANTITY;
        byte tilesInColumn = MIN_QUANTITY;
//         char whiteTileSign = 'x';
//         char blackTileSign = '*';
        char choosedSign = whiteTileSign;

        //take parameters and check if they are correct
        try {
            tileWidth = Byte.parseByte(args[0]);
            tileHeight = Byte.parseByte(args[1]);
            tilesInRow = Byte.parseByte(args[2]);
            tilesInColumn = Byte.parseByte(args[3]);
            whiteTileSign = args[4].charAt(0);
            blackTileSign = args[5].charAt(0);

            if (tileWidth < MIN_QUANTITY || tileWidth > MAX_QUANTITY ||
                    tileHeight < MIN_QUANTITY || tileHeight > MAX_QUANTITY ||
                    tilesInRow < MIN_QUANTITY || tilesInRow > MAX_QUANTITY ||
                    tilesInColumn < MIN_QUANTITY || tilesInColumn > MAX_QUANTITY) {
                System.exit(0);
            }

        } catch (NumberFormatException n) {
            System.exit(0);
        } catch (ArrayIndexOutOfBoundsException n) {
            System.exit(0);
        }

        //draw whole board
        for (int i = 0; i < tilesInColumn; i++) {
            drawTilesRow(choosedSign, tileHeight, tileWidth, tilesInRow);
            choosedSign = chooseSign(choosedSign, whiteTileSign, blackTileSign);
        }
    }

    //helper method for draw whole row, line by line
    private static void drawTilesRow(char actualSign, int tileHeight, int tileWidth, int tilesInRow) {

        while (tileHeight > 0) {
            tileHeight--;
            drawTilesLine(actualSign, tileWidth, tilesInRow);
        }
        return;
    }

    //helper method for draw single line of one row
    private static void drawTilesLine(char actualSign, int tileWidth, int tilesInRow) {
        for (int i = 0; i < tileWidth; i++) {
            System.out.print(actualSign);
        }
        tilesInRow--;
        actualSign = chooseSign(actualSign, whiteTileSign, blackTileSign);
        if (tilesInRow > 0) {
            drawTilesLine(actualSign, tileWidth, tilesInRow);
        } else {
            System.out.println();
            return;
        }
    }

    //helper method for changing color of the tile to the opposite to the currently drawn
    public static char chooseSign(char actualSign, char whiteTileSign, char blackTileSign) {
        if (actualSign == whiteTileSign) {
            actualSign = blackTileSign;
        } else {
            actualSign = whiteTileSign;
        }
        return actualSign;
    }
}
