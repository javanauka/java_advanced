package com.company;

public class InputCheck {
    private static final int MIN_ROCKET_SIZE = 1;
    private static final int MAX_ROCKET_SIZE = 75;


    public static void main(String[] args) {
        int rozmiar_rakiety = 1;
        char shield_on = '*';

        try {
            rozmiar_rakiety = Integer.parseInt(args[0]);
            shield_on = args[1].charAt(0);

            if (rozmiar_rakiety < MIN_ROCKET_SIZE || rozmiar_rakiety > MAX_ROCKET_SIZE ||
                    shield_on != 'Y' || shield_on != 'N') {
                System.out.println("zle dane wejsciowe");
                System.exit(0);
            }

        } catch (NumberFormatException n) {
            System.out.println("catch 1");
            System.exit(0);

        } catch (ArrayIndexOutOfBoundsException n) {
            System.out.println("catch 2");
            System.exit(0);
        }

//        System.out.printf("%d  %d  %d %d %c %c", tileWidth, tileHeight, tilesInRow, tilesInColumn, whiteTileSign, blackTileSign);
    }
}
