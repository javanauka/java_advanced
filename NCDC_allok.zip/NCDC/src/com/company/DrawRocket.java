package com.company;

public class DrawRocket {

    public static void drawSign(int charInLevel) {
        for (int i = 0; i < charInLevel; i++) {
            System.out.print("*");
        }
    }
//    public static void drawElement(int charInLevel, char sign) {
//        for (int i = 0; i < charInLevel; i++) {
//            System.out.print(sign);
//        }
//    }

    public static void drawSpace(int charInLevel) {
//        if (charInLevel > 0) {
            for (int i = 0; i < charInLevel; i++) {
                System.out.print(" ");
//            }
//        } else return;
    }}

    public static void drawShieldUp(int charInLevel) {
        for (int i = 0; i < charInLevel; i++) {
            System.out.print("\\");
        }
    }

    public static String drawSpaceSh(int charInLevel) {
        String rocketPart = "";
//        StringBuilder addRocketPart = new StringBuilder(rocketPart);
        for (int i = 0; i < charInLevel; i++){
rocketPart +=" ";

        }
//        String test = addRocketPart.toString();
        return rocketPart;
    }
    public static String drawSignSh(int charInLevel) {
        String rocketPart = "";
        for (int i = 0; i < charInLevel; i++) {
            rocketPart +="*";
        }
        return rocketPart;
    }
}
