//package com.company;
//
//public class DrawChess1 {
//
//
//    public static void drawTilesRow(char actualSign, int tileHeight, int tileWidth, int tilesInRow) {
////        int keepTileWidth = tileWidth;
////        int keepTilesInRow = tilesInRow;
////        if (tilesInRow>0) {
////        for (int i = 0; i < tileWidth; i++) {
////            System.out.print(actualSign);
////        }
////        actualSign = chooseSign(actualSign);
////        tilesInRow--;
////        } else tilesInRow = keepTilesInRow;
//        drawTilesLine(actualSign, tileWidth,tilesInRow);
//
//        if (tileHeight > 0) {
//            tileHeight--;
//            drawTilesLine(actualSign, tileWidth,tilesInRow);
//        } else {
//            System.out.println();
//            return;
//        }
////        System.out.println();
////        drawTile1(actualSign, tileHeight, keepTileWidth, tilesInRow);
//
//    }
//
//    public static void drawTilesLine(char actualSign, int tileWidth, int tilesInRow) {
//        for (int i = 0; i < tileWidth; i++) {
//            System.out.print(actualSign);
//        }
//        actualSign = chooseSign(actualSign);
//        if (tilesInRow>0) {
//            tilesInRow--;
//            drawTilesLine(actualSign, tileWidth, tilesInRow);
//        } else {
//            System.out.println();
//            return;
//        }
//    }
//
//    public static void drawTile(char actualSign, int tileHeight, int tileWidth, int tilesInRow) {
//        int keepTileWidth = tileWidth;
////       int keepTileHight = tileHeight;
//
//
//        for (int i = 0; i < tilesInRow; i++) {
//            tileWidth = keepTileWidth;
//            while (tileWidth > 0) {
//                System.out.print(actualSign);
//                tileWidth--;
//            }
//            actualSign = DrawChess1.chooseSign(actualSign);
//        }
//        if (tileHeight > 0) {
//            tileHeight--;
//        } else {
//            System.out.println();
//            return;
//        }
//        actualSign = DrawChess1.chooseSign(actualSign);
//        System.out.println();
//        drawTile(actualSign, tileHeight, keepTileWidth, tilesInRow);
//    }
//
//    public static char chooseSign(char actualSign) {
//        char sign = 'x';
//        if (actualSign == 'x') {
//            sign = '*';
//        } else {
//            sign = 'x';
//        }
//        return sign;
//    }
//}
