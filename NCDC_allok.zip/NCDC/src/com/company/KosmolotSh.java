package com.company;

public class KosmolotSh {
    public static int rozmiar_rakiety = 1;


    public static void main(String[] args) {
//        int hlp = 0;
//        if (rozmiar_rakiety == 1) {
//            System.out.println(">");
//            System.exit(0);
//        }
        String rocketLine = "";
        for (int i = 1; i <= rozmiar_rakiety; i++) {
            System.out.print(">");
            if (i == (rozmiar_rakiety) && rozmiar_rakiety!=1) {
                    DrawRocket.drawSign(rozmiar_rakiety*rozmiar_rakiety-2);
                System.out.print(">");
                break;
                }
            rocketLine = "";
            for (int j = 0; j < rozmiar_rakiety; j++) {
        rocketLine += DrawRocket.drawSpaceSh(rozmiar_rakiety-i);
                rocketLine += DrawRocket.drawSignSh(i-1);
                rocketLine += "\\";
            }
            System.out.println(rocketLine.substring(rozmiar_rakiety-i+1));
        }
////////////draw bottom of rocket/////////////
        if (rozmiar_rakiety==1) System.exit(0);
        System.out.println();
        for (int i = rozmiar_rakiety-1; i > 0; i--) {
            if (rozmiar_rakiety==1) break;
            System.out.print(">");
            rocketLine = "";
            for (int j = rozmiar_rakiety-1; j >=0; j--) {
                rocketLine += DrawRocket.drawSpaceSh(rozmiar_rakiety-i);
                rocketLine += DrawRocket.drawSignSh(i-1);
                rocketLine += "/";
            }
            System.out.println(rocketLine.substring(rozmiar_rakiety-i+1));
        }






    }
//        for (int i = 0; i < rozmiar_rakiety; i++) {
//            System.out.print(">");
//            if (i == (rozmiar_rakiety - 1)) {
//                    DrawRocket.drawSign(rozmiar_rakiety*rozmiar_rakiety-2);
//                System.out.print(">");
//                break;
//                }
//
//            for (int j = 0; j < rozmiar_rakiety-1; j++) {
//                DrawRocket.drawSpace(rozmiar_rakiety-i-1);
//                DrawRocket.drawSign(i);
//                System.out.print("\\");
//                hlp = rozmiar_rakiety - i;
////                DrawRocket.drawSpace(hlp); //rozmiar_rakiety-i
//            }
//
//            System.out.println();
//        }
//        rocketLine += "  ";
//                rocketLine += "*";
//                rocketLine += "\\";
//                System.out.print(rocketLine);
//    }
}

