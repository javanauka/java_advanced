package com.company;

public class Szachownica {
    public static void main(String[] args) {
        int tileWidth = 2;
        int tileHight = 3;
        int tilesInRow = 7;
        int tilesInColumn = 4;
        char whiteTileSign = 'x';
        char blackTileSign = '*';
        char choosedSign = whiteTileSign;

//        for (int i = 0; i < tilesInColumn; i++) {
//            while (tilesInRow > 0) {
//                while (tileWidth > 0) {
//                    System.out.print(choosedSign);
//                    tileWidth--;
//                }
//                choosedSign = DrawChess.chooseSign(choosedSign);
//                tileWidth = 2;
//                tilesInRow--;
//
//            }
//            System.out.println();
//            tilesInRow=2;
//        }
        for (int i = 0; i < tilesInColumn; i++) {
            DrawChess.drawTile(choosedSign, tileHight, tileWidth, tilesInRow);
            choosedSign = DrawChess.chooseSign(choosedSign);
        }
    }
}
