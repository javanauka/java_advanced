//program draws parallelogram with parameters: width height kick
package com.company;//na com.ncdc

import static java.lang.Math.abs;

public class Rownoleglobok {
    private static final char SIGN = '*';
    private static final char SPACE = ' ';
    private static final byte MIN_PARALLELOGRAM_SIZE = 1;
    private static final byte MAX_PARALLELOGRAM_SIZE = 100;
    private static final byte MIN_KICK_SIZE = -100;
    private static final byte MAX_KICK_SIZE = 100;

    public static void main(String[] args) {
        byte width = MIN_PARALLELOGRAM_SIZE;
        byte height = MIN_PARALLELOGRAM_SIZE;
        byte kick = MIN_PARALLELOGRAM_SIZE;

//take parameters and check if they are correct
        try {
            width = Byte.parseByte(args[0]);
            height = Byte.parseByte(args[1]);
            kick = Byte.parseByte(args[2]);

            if (width < MIN_PARALLELOGRAM_SIZE || width > MAX_PARALLELOGRAM_SIZE ||
                    height < MIN_PARALLELOGRAM_SIZE || height > MAX_PARALLELOGRAM_SIZE ||
                    kick < MIN_KICK_SIZE || kick > MAX_KICK_SIZE) {
                System.exit(0);
            }

        } catch (NumberFormatException n) {
            System.exit(0);
        } catch (ArrayIndexOutOfBoundsException n) {
            System.exit(0);
        }

//check is there any kick, draw elements of parallelogram depending on it's direction
        if (kick > 0) {
            for (int i = 0; i < height; i++) {
                drawSign(i * kick, SPACE);
                drawSign(width, SIGN);
                System.out.println();
            }

        } else if (kick < 0) {
            for (int i = --height; i >= 0; i--) {
                drawSign(abs(kick * i), SPACE);
                drawSign(width, SIGN);
                System.out.println();
            }

        } else {
            for (int i = 0; i < height; i++) {
                drawSign(width, SIGN);
                System.out.println();
            }
        }
    }

    //helper method for drawing sign or kick in parallelogram
    static void drawSign(int howLong, char element) {
        for (int i = 0; i < howLong; i++) {
            System.out.print(element);
        }
    }
}