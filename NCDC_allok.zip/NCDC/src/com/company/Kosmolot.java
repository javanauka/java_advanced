//program draws rocket with two parameters: rozmiar_rakiety shield_on
package com.company;

public class Kosmolot {
    private static final char SIGN = '*';
    private static final char SPACE = ' ';
    private static final char SHIELD_UP = '\\';
    private static final char SHIELD_DOWN = '/';
    private static final char THRUSTERS = '>';
    private static final int MIN_ROCKET_SIZE = 1;
    private static final int MAX_ROCKET_SIZE = 75;
    private static final byte OFFSET = 1;
    private static final byte CORE_LIMITER = 2;

    private static byte rozmiar_rakiety = 3;
    private static char shield_on = 'Y';
    private static String isEmpty = "";
    private static String rocketLine = isEmpty;

    public static void main(String[] args) {

        //take parameters and check if they are correct
        try {
            rozmiar_rakiety = Byte.parseByte(args[0]);
            shield_on = args[1].charAt(0);

            if (rozmiar_rakiety < MIN_ROCKET_SIZE || rozmiar_rakiety > MAX_ROCKET_SIZE ||
                    (shield_on != 'Y' && shield_on != 'N')) {
                System.exit(0);
            }

        } catch (NumberFormatException n) {
            System.exit(0);

        } catch (ArrayIndexOutOfBoundsException n) {
            System.exit(0);
        }

        switch (shield_on) {
            //draw rocket without shield
            case ('N'): {
                //draw upper half of the rocket without shield
                for (int i = 1; i <= rozmiar_rakiety; i++) {
                    for (int j = 0; j < rozmiar_rakiety; j++) {
                        drawElement(i, SIGN);
                        drawElement(rozmiar_rakiety - i, SPACE); //rozmiar_rakiety-i
                    }
                    System.out.println();
                }
                //draw lower half of the rocket without shield
                for (int i = rozmiar_rakiety - OFFSET; i >= 1; i--) {
                    for (int j = rozmiar_rakiety; j >= 1; j--) {
                        drawElement(i, SIGN);
                        drawElement(rozmiar_rakiety - i, SPACE); //rozmiar_rakiety-i
                    }
                    System.out.println();
                }
            }
            break;
            //draw rocket with shield
            case ('Y'): {
                //draw upper half of shielded rocket
                for (int i = 1; i <= rozmiar_rakiety; i++) {
                    System.out.print(THRUSTERS);
                    if (i == (rozmiar_rakiety) && rozmiar_rakiety != OFFSET) {
                        drawElement(rozmiar_rakiety * rozmiar_rakiety - CORE_LIMITER, SIGN);
                        System.out.print(THRUSTERS);
                        break;
                    }
                    rocketLine = isEmpty;
                    for (int j = 0; j < rozmiar_rakiety; j++) {
                        rocketLine += drawShieldedElement(rozmiar_rakiety - i, SPACE);
                        rocketLine += drawShieldedElement(i - OFFSET, SIGN);
                        rocketLine += SHIELD_UP;
                    }
                    System.out.println(rocketLine.substring(rozmiar_rakiety - i + OFFSET));
                }

                //draw bottom half of shielded rocket
                if (rozmiar_rakiety == OFFSET) System.exit(0);
                System.out.println();
                for (int i = rozmiar_rakiety - OFFSET; i > 0; i--) {
                    if (rozmiar_rakiety == OFFSET) break;
                    System.out.print(THRUSTERS);
                    rocketLine = isEmpty;
                    for (int j = rozmiar_rakiety - OFFSET; j >= 0; j--) {
                        rocketLine += drawShieldedElement(rozmiar_rakiety - i, SPACE);
                        rocketLine += drawShieldedElement(i - OFFSET, SIGN);
                        rocketLine += SHIELD_DOWN;
                    }
                    System.out.println(rocketLine.substring(rozmiar_rakiety - i + OFFSET));
                }
            }
            break;
            default:
                System.exit(0);
        }
    }

    //helper method for drawing element of the rocket with shield
    private static String drawShieldedElement(int charInRocketLevel, char sign) {
        String rocketPart = isEmpty;
        for (int i = 0; i < charInRocketLevel; i++) {
            rocketPart += sign;
        }
        return rocketPart;
    }

    //helper method for drawing element of the rocket without shield
    private static void drawElement(int charInLevel, char sign) {
        for (int i = 0; i < charInLevel; i++) {
            System.out.print(sign);
        }
    }
}

